# Sequência de Treinos

App Android minimalista com widget de tela inicial.

Sequência: PEITO → COSTAS → PERNAS → OMBROS → BRAÇOS → PEITO...

O treino atual fica maior no centro; o widget mostra os próximos itens menores. O botão do widget conclui o treino e avança a sequência.

Abra este projeto no Android Studio e gere o APK. Depois, instale no Galaxy A55 e adicione o widget à tela inicial.
