package com.sequenciatreinos

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.widget.RemoteViews

class WorkoutWidget : AppWidgetProvider() {
    companion object {
        private val names = arrayOf("PEITO", "COSTAS", "PERNAS", "OMBROS", "BRAÇOS")
        private const val PREFS = "workout_state"
        private const val KEY = "index"
        private const val ACTION = "com.sequenciatreinos.COMPLETE"
        fun refresh(context: Context) { val mgr=AppWidgetManager.getInstance(context); val ids=mgr.getAppWidgetIds(ComponentName(context,WorkoutWidget::class.java)); WorkoutWidget().onUpdate(context,mgr,ids) }
        private fun index(context: Context)=context.getSharedPreferences(PREFS,0).getInt(KEY,0)
        private fun setIndex(context: Context, value:Int)=context.getSharedPreferences(PREFS,0).edit().putInt(KEY,value).apply()
    }
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { val i=index(context); ids.forEach { id ->
        val v=RemoteViews(context.packageName,R.layout.widget); v.setTextViewText(R.id.above1,names[(i-1+5)%5]); v.setTextViewText(R.id.current,names[i]); v.setTextViewText(R.id.below1,names[(i+1)%5]); v.setTextViewText(R.id.below2,names[(i+2)%5])
        val pi=PendingIntent.getBroadcast(context,0,Intent(context,WorkoutWidget::class.java).setAction(ACTION),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); v.setOnClickPendingIntent(R.id.complete,pi); manager.updateAppWidget(id,v)
    }}
    override fun onReceive(context: Context, intent: Intent) { super.onReceive(context,intent); if(intent.action==ACTION){setIndex(context,(index(context)+1)%5); refresh(context)} }
}
