package com.sequenciatreinos

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.widget.Button
import android.content.Context

class MainActivity : Activity() {
    private val names = arrayOf("PEITO", "COSTAS", "PERNAS", "OMBROS", "BRAÇOS")
    private var index = 0
    private fun render() {
        val ids = intArrayOf(R.id.above2, R.id.above1, R.id.current, R.id.below1, R.id.below2)
        val offsets = intArrayOf(-2, -1, 0, 1, 2)
        ids.forEachIndexed { i, id -> findViewById<TextView>(id).text = names[(index + offsets[i] + names.size) % names.size] }
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        index = getPreferences(Context.MODE_PRIVATE).getInt("index", 0); render()
        findViewById<Button>(R.id.complete).setOnClickListener { index=(index+1)%names.size; getPreferences(Context.MODE_PRIVATE).edit().putInt("index",index).apply(); render(); WorkoutWidget.refresh(this) }
    }
}
